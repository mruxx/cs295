﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SongsApi.Models
{
    public class Song
    {
        public int ID { get; set; }

        [StringLength(120, MinimumLength = 3)]
        [Required]
        public string Title { get; set; }

        [Display(Name = "Release Date")]
        [DataType(DataType.Date)]
        public DateTime PublishDate { get; set; }

        [StringLength(120, MinimumLength = 3)]
        [Required]
        public string Artist { get; set; }

        [StringLength(120, MinimumLength = 3)]
        [Required]
        public string Album { get; set; }

        [StringLength(120, MinimumLength = 3)]
        [Required]
        public string Writer { get; set; }

        [StringLength(120, MinimumLength = 3)]
        [Required]
        public string Composer { get; set; }

        [RegularExpression(@"\*{1,5}")]
        public string Rating { get; set; }
    }
}
