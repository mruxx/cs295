﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using SongsApi.Models;
using System.Linq;
using System;

namespace TodoApi.Controllers
{
    
    [Route("api/songs")]
    public class SongController : Controller
    {
        private readonly SongContext _context;

        public SongController(SongContext context)
        {
            _context = context;

            if (_context.Song.Count() == 0)
            {

                _context.Song.Add(new Song {    Title = "Song Number One",
                                                Album = "Stuff Factory",
                                                Artist = "Steve",
                                                Composer = "Turtle Face",
                                                PublishDate = Convert.ToDateTime("11/26/1997"),
                                                Rating ="***",
                                                Writer = "Steve's Brother" });

                _context.SaveChanges();
            }
        }

        // host/api/songs
        [HttpGet]
        public IEnumerable<Song> GetAll()
        {
            return _context.Song.ToList();
        }

        // host/api/songs/{id}
        [HttpGet("{id}", Name = "GetSong")]
        public IActionResult GetById(long id)
        {
            var item = _context.Song.FirstOrDefault(t => t.ID == id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }

        // POST  host/api/songs
        [HttpPost]
        public IActionResult Create([FromBody] Song song)
        {
            if (song == null)
            {
                return BadRequest();
            }

            _context.Song.Add(song);
            _context.SaveChanges();

            return CreatedAtRoute("GetSong", new { id = song.ID }, song);
        }

        // PUT host/api/songs/{id}
        [HttpPut("{id}")]
        public IActionResult Update(long id, [FromBody] Song song)
        {
            if (song == null || song.ID != id)
            {
                return BadRequest();
            }

            var nSong = _context.Song.FirstOrDefault(t => t.ID == id);
            if (nSong == null)
            {
                return NotFound();
            }

            nSong.Title = song.Title;
            nSong.PublishDate = song.PublishDate;
            nSong.Artist = song.Artist;
            nSong.Album = song.Album;
            nSong.Writer = song.Writer;
            nSong.Composer = song.Composer;
            nSong.Rating = song.Rating;

            _context.Song.Update(nSong);
            _context.SaveChanges();
            return new NoContentResult();
        }

        // DELETE host/api/songs/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            var nSong = _context.Song.FirstOrDefault(t => t.ID == id);
            if (nSong == null)
            {
                return NotFound();
            }

            _context.Song.Remove(nSong);
            _context.SaveChanges();
            return new NoContentResult();
        }
    }
}