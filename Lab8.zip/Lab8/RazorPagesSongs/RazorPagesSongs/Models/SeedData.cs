﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace RazorPagesSongs.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new SongContext(
                serviceProvider.GetRequiredService<DbContextOptions<SongContext>>()))
            {
                // Look for any movies.
                if (context.Song.Any())
                {
                    return;   // DB has been seeded
                }

                context.Song.AddRange(
                    new Song
                    {
                        Album = "Totally Future",
                        Artist = "Jesus and the Cosmonaut",
                        Composer = "The Cosmonaut",
                        PublishDate = DateTime.Parse("2016-2-20"),
                        Title = "Totally Future",
                        Writer = "Bill",
                        Rating = "*****"
                    },

                    new Song
                    {
                        Album = "Totally Future",
                        Artist = "Jesus and the Cosmonaut",
                        Composer = "The Cosmonaut",
                        PublishDate = DateTime.Parse("2016-2-20"),
                        Title = "OK gravy",
                        Writer = "Bill",
                        Rating = "*****"
                    },

                    new Song
                    {
                        Album = "We Got Trumpets",
                        Artist = "Flang",
                        Composer = "Todd Bubbles",
                        PublishDate = DateTime.Parse("2015-5-12"),
                        Title = "Big March Spring",
                        Writer = "Jeff Jon-Jo",
                        Rating = "*****"
                    },

                    new Song
                    {
                        Album = "We Got Trumpets",
                        Artist = "Flang",
                        Composer = "Todd Bubbles",
                        PublishDate = DateTime.Parse("2015-5-12"),
                        Title = "Spirits",
                        Writer = "Jeff Jon-Jo",
                        Rating = "*****"
                    },

                    new Song
                    {
                        Album = "If not now. Tomorrow.",
                        Artist = "ACEgerm",
                        Composer = "Fi Fi'AAlee",
                        PublishDate = DateTime.Parse("2002-7-19"),
                        Title = "Langsame Mechanik",
                        Writer = "Wilhelm Frueh",
                        Rating = "*****"
                    },

                    new Song
                    {
                        Album = "If not now. Tomorrow.",
                        Artist = "ACEgerm",
                        Composer = "Fi Fi'AAlee",
                        PublishDate = DateTime.Parse("2002-7-19"),
                        Title = "Im Herzen Brennen",
                        Writer = "Wilhelm Frueh",
                        Rating = "****"
                    },

                    new Song
                    {
                        Album = "If not now. Tomorrow.",
                        Artist = "ACEgerm",
                        Composer = "Fi Fi'AAlee",
                        PublishDate = DateTime.Parse("2002-7-19"),
                        Title = "Schlafen",
                        Writer = "Wilhelm Frueh",
                        Rating = "****"
                    },

                    new Song
                    {
                        Album = "If not now. Tomorrow.",
                        Artist = "ACEgerm",
                        Composer = "Fi Fi'AAlee",
                        PublishDate = DateTime.Parse("2002-7-19"),
                        Title = "Meine Flut",
                        Writer = "Wilhelm Frueh",
                        Rating = "****"
                    }
                );
                context.SaveChanges();
            }
        }
    }
}