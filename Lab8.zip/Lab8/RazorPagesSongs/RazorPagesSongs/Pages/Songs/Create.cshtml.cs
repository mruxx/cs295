using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using RazorPagesSongs.Models;
using Microsoft.AspNetCore.Http;

namespace RazorPagesSongs.Pages.Songs
{
    public class CreateModel : PageModel
    {
        //Constants for HTTP Session
        static string LAST_ARTIST = "LastArtist";
        static string LAST_ALBUM = "LastAlbum";

        private readonly RazorPagesSongs.Models.SongContext _context;

        public CreateModel(RazorPagesSongs.Models.SongContext context)
        {
            _context = context;
        }

        public IActionResult OnGet() //Using a simple OnGet for the create page we can run the Session retrieval
        {
            RetrieveLastArtistAndAlbum(); //Method to save HTTP Session Last Artist/Album
            return Page();
        }

        [BindProperty]
        public Song Song { get; set; }
        public string LastArtist { get; set; } //Property for LastArtist Recall
        public string LastAlbum { get; set; } //Property for LastAlbum Recall

        public async Task<IActionResult> OnPostAsync() //OnPostAsync is where we ant our Session object saving
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Song.Add(Song);
            LastArtist = Song.Artist; //Save Artist variable of currnet Song object to LastArtist Variable
            LastAlbum = Song.Album; //Save Album variable of the current Song object to the LastAlbum Variable
            SaveLastArtistAndAlbum(); //Run the HTTP Session method to save the Last Artist and Album
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private void SaveLastArtistAndAlbum() //HTTP Session Save
        {
            HttpContext.Session.SetString(LAST_ARTIST, (Song.Artist) ?? "");
            HttpContext.Session.SetString(LAST_ALBUM, (Song.Album) ?? "");
        }

        private void RetrieveLastArtistAndAlbum() //HTTP Session Retrieve
        {
            LastArtist = HttpContext.Session.GetString(LAST_ARTIST);
            LastAlbum = HttpContext.Session.GetString(LAST_ALBUM);
        }
    }
}