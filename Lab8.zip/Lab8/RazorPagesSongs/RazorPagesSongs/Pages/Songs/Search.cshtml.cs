using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RazorPagesSongs.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace RazorPagesSongs.Pages.Songs
{
    public class SearchModel : PageModel
    {
        private readonly RazorPagesSongs.Models.SongContext _context;

        public SearchModel(RazorPagesSongs.Models.SongContext context)
        {
            _context = context;
        }

        public IList<Song> Song { get; set; }
        public SelectList SongRating;
        public string Rating { get; set; }

        public async Task OnGetAsync(string searchAlbum, string searchTitle, string searchDateLow, string searchDateHigh)
        {
            // Use LINQ to get list of albums
            IQueryable<string> ratingQuery = from so in _context.Song
                                                orderby so.Rating
                                                select so.Rating;

            var songs = from so in _context.Song
                        select so;

            DateTime low = Convert.ToDateTime(searchDateLow);
            DateTime high = Convert.ToDateTime(searchDateHigh);

            if (!String.IsNullOrEmpty(searchTitle))
            {
                songs = songs.Where(se => se.Title.Contains(searchTitle));
            }

            //Added date search here
            //The LAMBA expressions allow for easier handling, this one is not a lambda. It is first to prevent it to overriding songs as written.
            if (!String.IsNullOrEmpty(searchDateHigh))
            {
                songs = from so in _context.Song
                        where so.PublishDate <= high
                        select so;
            }

            if (!String.IsNullOrEmpty(searchDateLow))
            {
                songs = songs.Where(se => (se.PublishDate.CompareTo(low)) > 0);
            }


            if (!String.IsNullOrEmpty(searchAlbum))
            {
                songs = songs.Where(se => se.Album.Contains(searchAlbum));
            }

            SongRating = new SelectList(await ratingQuery.Distinct().ToListAsync());

            Song = await songs.ToListAsync();
        }
    }
}
