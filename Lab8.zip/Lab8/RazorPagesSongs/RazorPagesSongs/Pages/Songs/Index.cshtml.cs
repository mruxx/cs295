using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RazorPagesSongs.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace RazorPagesSongs.Pages.Songs
{
    public class IndexModel : PageModel
    {
        private readonly RazorPagesSongs.Models.SongContext _context;

        public IndexModel(RazorPagesSongs.Models.SongContext context)
        {
            _context = context;
        }

        public IList<Song> Song { get;set; }

        public async Task OnGetAsync(string songAlbum, string searchString)
        {
            var songs = from so in _context.Song
                         select so;

            if (!String.IsNullOrEmpty(searchString))
            {
                songs = songs.Where(se => se.Title.Contains(searchString));
            }

            if (!String.IsNullOrEmpty(songAlbum))
            {
                songs = songs.Where(x => x.Album == songAlbum);
            }

            Song = await songs.ToListAsync();
        }
    }
}
