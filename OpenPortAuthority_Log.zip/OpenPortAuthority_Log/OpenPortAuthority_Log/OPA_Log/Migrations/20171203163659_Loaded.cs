﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace OPA_Log.Migrations
{
    public partial class Loaded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "EntryBy",
                table: "LogEntry",
                nullable: true,
                oldClrType: typeof(decimal));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "EntryBy",
                table: "LogEntry",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);
        }
    }
}
