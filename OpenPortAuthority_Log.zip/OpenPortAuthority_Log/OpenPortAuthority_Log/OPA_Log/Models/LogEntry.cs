﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OPA_Log.Models
{
    public class LogEntry
    {
        //Required validations still need to be added
        public int ID { get; set; }
        [Display(Name = "Entry Type")]
        public string Type { get; set; }
        [Display(Name = "Name Of Vessel")]
        public string Vessel_Name { get; set; }
        [Display(Name = "Vessel Designation")]
        public string Vessel_Designation { get; set; }
        [Display(Name = "Dock Number")]
        public string Dock { get; set; }
        [Display(Name = "Time Stamp")]
        public DateTime LogTime { get; set; }
        public string Entry { get; set; }
        [Display(Name = "Entry By")]
        public string EntryBy { get; set; }
    }
}
