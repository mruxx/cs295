﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace OPA_Log.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new LogEntryContext(
                serviceProvider.GetRequiredService<DbContextOptions<LogEntryContext>>()))
            {
                // Look for any entries.
                if (context.LogEntry.Any())
                {
                    return;   // DB has been seeded
                }

                context.LogEntry.AddRange(
                    new LogEntry
                    {
                        Type = "Dock Request",
                        Vessel_Name = "HMS Hood",
                        Vessel_Designation = "UKSN-51",
                        Dock = "Torus 1",
                        LogTime = DateTime.Parse("2017-2-20 5:32:13"),
                        Entry = "HMS Hood requested to Dock at Torus #1.",
                        EntryBy = "SCV"
                    },

                    new LogEntry
                    {
                        Type = "Dock Denied",
                        Vessel_Name = "HMS Hood",
                        Vessel_Designation = "UKSN-51",
                        Dock = "Torus 1",
                        LogTime = DateTime.Parse("2017-2-20 5:33:20"),
                        Entry = "HMS Hood denied docking at Torus #1 due to maintenance of the main door's secondary servo module.",
                        EntryBy = "SCV"
                    },

                    new LogEntry
                    {
                        Type = "Dock Granted",
                        Vessel_Name = "HMS Hood",
                        Vessel_Designation = "UKSN-51",
                        Dock = "Torus 3",
                        LogTime = DateTime.Parse("2017-2-20 5:33:33"),
                        Entry = "HMS Hood granted docking rights at Torus #3.",
                        EntryBy = "SCV"
                    },

                    new LogEntry
                    {
                        Type = "Dock Successful",
                        Vessel_Name = "HMS Hood",
                        Vessel_Designation = "UKSN-51",
                        Dock = "Torus 3",
                        LogTime = DateTime.Parse("2017-2-20 5:40:03"),
                        Entry = "HMS Hood successfully docked at Torus #3.",
                        EntryBy = "SCV"
                    },

                    new LogEntry
                    {
                        Type = "Dock Requested",
                        Vessel_Name = "Waffle House Freight - Marten V",
                        Vessel_Designation = "CC-WHF-MV",
                        Dock = "B2",
                        LogTime = DateTime.Parse("2017-2-22 12:22:02"),
                        Entry = "This vessel requested docking using designator CC-WHF-MV, however their identification transponder is broadcasting an out of date Waffle House Freight ID code. Recommend that the vessel is scanned for contraband.",
                        EntryBy = "TRO"
                    },

                    new LogEntry
                    {
                        Type = "Event",
                        Vessel_Name = "Waffle House Freight - Marten V",
                        Vessel_Designation = "CC-WHF-MV",
                        Dock = "B2",
                        LogTime = DateTime.Parse("2017-2-22 12:23:11"),
                        Entry = "A sub-material phase scan returned traces of narcotic contraband in 3 of 15 cargo containers identfied within this vessel.",
                        EntryBy = "BBR"
                    },

                    new LogEntry
                    {
                        Type = "Dock Denied",
                        Vessel_Name = "Waffle House Freight - Marten V",
                        Vessel_Designation = "CC-WHF-MV",
                        Dock = "B2",
                        LogTime = DateTime.Parse("2017-2-22 12:25:17"),
                        Entry = "Dock with the station was denied due to the presence of contraband. Vessel was informed that it cannot dock while containing narcotic contraband and that for docking to be granted they must jettison the cargo to be destroyed or they may return without it.",
                        EntryBy = "TRO"
                    },

                    new LogEntry
                    {
                        Type = "Note",
                        Vessel_Name = "Waffle House Frieght - Marten V",
                        Vessel_Designation = "CC-WHF-MV",
                        Dock = "B2",
                        LogTime = DateTime.Parse("2017-2-22 12:28:00"),
                        Entry = "Do not allow this vessel to dock without first conducting a sub-material phase scan for contraband.",
                        EntryBy = "TRO"
                    },

                    new LogEntry
                    {
                        Type = "Undock Request",
                        Vessel_Name = "HMS Hood",
                        Vessel_Designation = "UKSN-51",
                        Dock = "Torus 3",
                        LogTime = DateTime.Parse("2017-2-27 00:07:06"),
                        Entry = "HMS Hood is reporting that it is ready to undock from Torus #3. Torus #3 crew has been alerted to initiate all pre-checks.",
                        EntryBy = "TRO"
                    },

                    new LogEntry
                    {
                        Type = "Undock Granted",
                        Vessel_Name = "HMS Hood",
                        Vessel_Designation = "UKSN-51",
                        Dock = "Torus 3",
                        LogTime = DateTime.Parse("2017-2-27 00:45:30"),
                        Entry = "All pre-checks are complete and Torus #3 crew reports that the HMS Hood interlocks are clear. Torus #3 Magnetic Release Control has been turned over to the HMS Hood - Semi-Autonomus flight assist controls have been engaged. Undocking rights are granted.",
                        EntryBy = "TRO"
                    },

                    new LogEntry
                    {
                        Type = "Undock Successful",
                        Vessel_Name = "HMS Hood",
                        Vessel_Designation = "UKSN-51",
                        Dock = "Torus 3",
                        LogTime = DateTime.Parse("2017-2-27 01:01:30"),
                        Entry = "HMS Hood has successfully undocked and is confirmed to be at a distance greater than 5km from the station. Semi-Autonomous flight assist controls have been released. Undock successful.",
                        EntryBy = "TRO"
                    }


                );
                context.SaveChanges();
            }
        }
    }
}