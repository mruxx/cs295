﻿using Microsoft.EntityFrameworkCore;

namespace OPA_Log.Models
{
    public class LogEntryContext : DbContext
    {
        public LogEntryContext(DbContextOptions<LogEntryContext> options)
                : base(options)
        {
        }

        public DbSet<LogEntry> LogEntry { get; set; }
    }
}