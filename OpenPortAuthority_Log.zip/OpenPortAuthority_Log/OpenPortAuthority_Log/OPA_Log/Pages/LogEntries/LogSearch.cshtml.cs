using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using OPA_Log.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace OPA_Log.Pages.LogEntries
{
    public class SearchModel : PageModel
    {
        private readonly OPA_Log.Models.LogEntryContext _context;

        public SearchModel(OPA_Log.Models.LogEntryContext context)
        {
            _context = context;
        }

        public IList<LogEntry> LogEntry { get; set; }
        public SelectList EntryType;
        public SelectList EntryDock;
        public SelectList EntryEntryBy;
        public string Type { get; set; }
        public string Dock { get; set; }
        public string EntryBy { get; set; }

        public async Task OnGetAsync
            (string searchID, string searchVesselName, string searchVesselDesignation, string type, string dock, string entryBy, string searchDateLow, string searchDateHigh)
        {
            // Use LINQ to get list of albums
            IQueryable<string> EntryTypeQuery = from le in _context.LogEntry
                                                orderby le.Type
                                                select le.Type;

            IQueryable<string> EntryDockQuery = from le in _context.LogEntry
                                                orderby le.Dock
                                                select le.Dock;

            IQueryable<string> EntryByQuery = from le in _context.LogEntry
                                                orderby le.EntryBy
                                                select le.EntryBy;

            var entries = from le in _context.LogEntry
                        select le;

            DateTime low = Convert.ToDateTime(searchDateLow);
            DateTime high = Convert.ToDateTime(searchDateHigh);

            if (!String.IsNullOrEmpty(searchID))
            {
                entries = entries.Where(le => le.ID.ToString().Contains(searchID));
            }

            //Added date search here
            //The LAMBA expressions allow for easier handling, this one is not a lambda. It is first to prevent it to overriding songs as written.
            if (!String.IsNullOrEmpty(searchDateHigh))
            {
                entries = entries.Where(se => (se.LogTime.CompareTo(high)) <= 0);
            }

            if (!String.IsNullOrEmpty(searchDateLow))
            {
                entries = entries.Where(se => (se.LogTime.CompareTo(low)) > 0);
            }


            if (!String.IsNullOrEmpty(searchVesselName))
            {
                entries = entries.Where(se => se.Vessel_Name.Contains(searchVesselName));
            }

            if (!String.IsNullOrEmpty(searchVesselDesignation))
            {
                entries = entries.Where(se => se.Vessel_Designation.Contains(searchVesselDesignation));
            }

            if (!String.IsNullOrEmpty(type))
            {
                entries = entries.Where(se => se.Type.Contains(type));
            }

            if (!String.IsNullOrEmpty(dock))
            {
                entries = entries.Where(se => se.Dock.Contains(dock));
            }

            if (!String.IsNullOrEmpty(entryBy))
            {
                entries = entries.Where(se => se.EntryBy.Contains(entryBy));
            }

            EntryType = new SelectList(await EntryTypeQuery.Distinct().ToListAsync());

            EntryDock = new SelectList(await EntryDockQuery.Distinct().ToListAsync());

            EntryEntryBy = new SelectList(await EntryByQuery.Distinct().ToListAsync());

            LogEntry = await entries.ToListAsync();
        }
    }
}
