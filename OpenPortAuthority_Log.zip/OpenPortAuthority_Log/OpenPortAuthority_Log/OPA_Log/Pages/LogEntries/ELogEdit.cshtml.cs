using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OPA_Log.Models;

namespace OPA_Log.Pages.LogEntries
{
    public class ELogEditModel : PageModel
    {
        private readonly OPA_Log.Models.LogEntryContext _context;

        public ELogEditModel(OPA_Log.Models.LogEntryContext context)
        {
            _context = context;
        }

        [BindProperty]
        public LogEntry LogEntry { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            LogEntry = await _context.LogEntry.SingleOrDefaultAsync(m => m.ID == id);

            if (LogEntry == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(LogEntry).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                
            }

            return RedirectToPage("./LogBrowser");
        }
    }
}
