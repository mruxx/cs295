using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using OPA_Log.Models;

namespace OPA_Log.Pages.LogEntries
{
    public class LogOutboundModel : PageModel
    {
        private readonly OPA_Log.Models.LogEntryContext _context;

        public LogOutboundModel(OPA_Log.Models.LogEntryContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public LogEntry LogEntry { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            LogEntry.LogTime = DateTime.Now; //Set the timestamp

            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.LogEntry.Add(LogEntry);
            await _context.SaveChangesAsync();

            return RedirectToPage("./LogBrowser");
        }
    }
}