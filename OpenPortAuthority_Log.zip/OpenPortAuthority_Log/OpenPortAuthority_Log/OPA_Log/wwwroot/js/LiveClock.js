﻿//JS for a live clock

var myVar = setInterval(function () {
	myTimer();
}, 1000);

function myTimer() {

	var d = new Date(); //Create a date object

	dStr = d.toLocaleDateString();
	tStr = d.toLocaleTimeString();


	document.getElementById("clock").innerHTML = dStr + " " + tStr;

}