using OPA_Log.Models;
using System;
using Xunit;

namespace Tester
{
    public class Tests
    {
        LogEntry logModel;

        public Tests()
        {
            DateTime thisDate = new DateTime();

            thisDate = DateTime.Parse("11/22/2017 12:00:00");

            logModel = new LogEntry();
            logModel.ID = 1;
            logModel.Type = "Dock Request";
            logModel.Vessel_Name = "USS Bill Cosby";
            logModel.Vessel_Designation = "UBC";
            logModel.LogTime = thisDate;
            logModel.Dock = "A1";
            logModel.Entry = "Nothing happened.";
            logModel.EntryBy = "Tom";
        }

        [Fact]
        public void TestModelDateObject()
        {
            DateTime thisDate = DateTime.Parse("11/22/2017 12:00:00");
            //Check that the date object can be loaded and unloaded correctly
            Assert.Equal(logModel.LogTime, thisDate);
        }

        [Fact]

        public void TestModelID()
        {
            Assert.Equal(logModel.ID, 1);
        }

        [Fact]
        public void TestModelType()
        {
            Assert.Equal(logModel.Type, "Dock Request");
        }

        [Fact]

        public void TestModelVesselName()
        {
            Assert.Equal(logModel.Vessel_Name, "USS Bill Cosby");
        }

        [Fact]

        public void TestModelVesselDes()
        {
            Assert.Equal(logModel.Vessel_Designation, "UBC");
        }

        [Fact]

        public void TestModelDock()
        {
            Assert.Equal(logModel.Dock, "A1");
        }

        [Fact]

        public void TestModelEntry()
        {
            Assert.Equal(logModel.Entry, "Nothing happened.");
        }

        public void TestModelEntryBy()
        {
            Assert.Equal(logModel.EntryBy, "Tom");
        }
    }
}
